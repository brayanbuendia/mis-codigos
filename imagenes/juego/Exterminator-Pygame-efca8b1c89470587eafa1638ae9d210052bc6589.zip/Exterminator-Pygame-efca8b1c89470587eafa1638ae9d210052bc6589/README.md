# Exterminator-Pygame

### English
This is a game created with Python's Pygame library. It is still under development.

V1.0 - Created the game screen with a window title.

https://bit.ly/2WQwjVC

V1.1 - Added a window icon and a static background.

https://bit.ly/2WUBzYq

V1.2 - Added a looped moving background and FPS control.

https://bit.ly/2yXPUer

V1.3 - Added main character with motion, jump and wait animations.

https://bit.ly/2y1cqCL

### Spanish
Este es un juego creado con la librería Pygame de Python. Todavía se encuentra en desarrollo.

V1.0 - Creada la pantalla de juego con un título de ventana.

https://bit.ly/2WQwjVC

V1.1 - Añadido un icono de ventana y un fondo estático.

https://bit.ly/2WUBzYq

V1.2 - Añadido un fondo en movimiento en bucle y control de FPS.

https://bit.ly/2yXPUer

V1.3 - Añadido el personaje principal con animaciones de movimiento, salto y espera.

https://bit.ly/2y1cqCL
